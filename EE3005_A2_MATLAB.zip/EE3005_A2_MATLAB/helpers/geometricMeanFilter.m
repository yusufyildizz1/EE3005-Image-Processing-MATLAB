function out = geometricMeanFilter(I, k)
% GEOMETRICMEANFILTER  Geometric mean filter with a k x k window.
%   out = ( prod g(s,t) )^(1/(k*k))
%   Same idea as the lecture code: exp( sum(log(g)) )^(1/mn).
%   eps is added because log(0) = -Inf for black (pepper) pixels.
I = im2double(I);
logSum = imfilter(log(I + eps), ones(k), 'replicate');
out = exp(logSum) .^ (1/(k*k));
end
