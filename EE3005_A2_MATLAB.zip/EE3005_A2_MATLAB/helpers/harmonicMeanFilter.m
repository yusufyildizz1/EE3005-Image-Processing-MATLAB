function out = harmonicMeanFilter(I, k)
% HARMONICMEANFILTER  Harmonic mean filter with a k x k window.
%   out = mn / sum( 1 ./ g(s,t) ),  eps avoids division by zero.
I = im2double(I);
out = (k*k) ./ imfilter(1 ./ (I + eps), ones(k), 'replicate');
end
