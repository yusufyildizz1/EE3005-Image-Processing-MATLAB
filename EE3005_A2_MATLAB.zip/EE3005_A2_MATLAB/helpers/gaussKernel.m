function g = gaussKernel(sigma)
% GAUSSKERNEL  2-D Gaussian kernel, size 2*ceil(3*sigma)+1 (covers +-3 sigma).
hsize = 2*ceil(3*sigma) + 1;
g = fspecial('gaussian', hsize, sigma);
end
