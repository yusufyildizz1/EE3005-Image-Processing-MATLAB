function s = highpassStd(I, rows, cols)
% HIGHPASSSTD  Std of the fine-scale fluctuations inside a region.
%   The local 5x5 mean is removed first, so slow shading does not count.
%   Used as a simple "noise / grain level" measure in a flat region.
R = I(rows, cols);
hp = R - imfilter(R, ones(5)/25, 'replicate');
hp = hp(3:end-2, 3:end-2);
s = std(hp(:));
end
