function saveFig(fig, fileName)
% SAVEFIG  Save a figure as PNG (150 dpi) into the figures folder.
P = getPaths();
set(fig, 'PaperPositionMode', 'auto');
outFile = fullfile(P.figures, [fileName '.png']);
drawnow;
print(fig, outFile, '-dpng', '-r150');
fprintf('   figure saved: figures/%s.png\n', fileName);
end
