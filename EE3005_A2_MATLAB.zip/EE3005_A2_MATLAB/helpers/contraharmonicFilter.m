function out = contraharmonicFilter(I, k, Q)
% CONTRAHARMONICFILTER  Contra-harmonic mean filter of order Q, k x k window.
%   out = sum( g^(Q+1) ) / sum( g^Q )
%   Q > 0 removes pepper noise, Q < 0 removes salt noise,
%   Q = 0 -> arithmetic mean, Q = -1 -> harmonic mean.
I = im2double(I) + eps;            % eps: 0^Q is Inf when Q < 0
num = imfilter(I.^(Q+1), ones(k), 'replicate');
den = imfilter(I.^Q,     ones(k), 'replicate');
out = num ./ den;
end
