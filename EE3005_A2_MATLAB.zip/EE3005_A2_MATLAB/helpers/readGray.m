function I = readGray(fileName)
% READGRAY  Read an image from the images folder as grayscale double in [0,1].
P = getPaths();
f = fullfile(P.images, fileName);
if ~exist(f, 'file')
    error('Image not found: %s', f);
end
I = imread(f);
if size(I, 3) == 3
    I = rgb2gray(I);
end
I = im2double(I);
end
