function p = computePSNR(ref, img)
% COMPUTEPSNR  PSNR in dB for double images in [0,1] (peak value = 1).
%   PSNR = 10*log10( 1 / MSE ),  MSE = mean((ref - img).^2)
%   This gives the same value as MATLAB psnr(img, ref) for double images.
img = min(max(img, 0), 1);            % same intensity range as the reference
mse = mean((ref(:) - img(:)).^2);
p = 10*log10(1 / mse);
end
