function fig = newFig(figName, pos)
% NEWFIG  White figure with a light theme (also in MATLAB dark mode).
if nargin < 2, pos = [60 60 1100 700]; end
fig = figure('Name', figName, 'Color', 'w', 'Position', pos, ...
             'NumberTitle', 'off');
try
    theme(fig, 'light');          % R2025a and newer, ignored otherwise
catch
end
end
