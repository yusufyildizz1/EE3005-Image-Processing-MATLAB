function [mag, Gx, Gy] = sobelMag(I)
% SOBELMAG  Sobel gradient magnitude (replicate padding).
sy = fspecial('sobel');        % [1 2 1; 0 0 0; -1 -2 -1] -> vertical change
sx = sy';                      % horizontal change
Gx = imfilter(I, sx, 'replicate');
Gy = imfilter(I, sy, 'replicate');
mag = sqrt(Gx.^2 + Gy.^2);
end
