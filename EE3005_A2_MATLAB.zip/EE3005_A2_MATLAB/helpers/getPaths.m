function P = getPaths()
% GETPATHS  Absolute paths of the assignment folders.
%   All paths are built from the location of this file, so the code works
%   no matter what the current MATLAB folder is.
helperDir = fileparts(mfilename('fullpath'));
P.base    = fileparts(helperDir);
P.images  = fullfile(P.base, 'images');
P.figures = fullfile(P.base, 'figures');
P.results = fullfile(P.base, 'results');
if ~exist(P.figures, 'dir'), mkdir(P.figures); end
if ~exist(P.results, 'dir'), mkdir(P.results); end
end
