function showHist(I, titleStr)
% SHOWHIST  Draw a 256-bin grey-level histogram of image I in the current axes.
if ~isa(I, 'uint8')
    I = im2uint8(I);
end
counts = imhist(I, 256);
bar(0:255, counts, 1, 'FaceColor', [0.35 0.35 0.35], 'EdgeColor', 'none');
xlim([-3 258]);
xlabel('grey level'); ylabel('number of pixels');
title(titleStr);
box on;
end
