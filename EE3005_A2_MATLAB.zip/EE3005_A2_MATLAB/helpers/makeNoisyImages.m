function N = makeNoisyImages(Iref)
% MAKENOISYIMAGES  Noisy versions of the reference image (fixed random seeds,
% so Task 4 and Task 5 use exactly the same noisy images).
%   N.gauss  : Gaussian noise, mean 0, variance 0.01 (sigma = 0.1)
%   N.sp     : salt & pepper noise, density 0.05
%   N.salt   : salt only (white pixels), probability 0.1
%   N.pepper : pepper only (black pixels), probability 0.1
rng(0); N.gauss = imnoise(Iref, 'gaussian', 0, 0.01);
N.gauss = min(max(N.gauss, 0), 1);   % keep [0,1] (MATLAB imnoise already clips)
rng(1); N.sp    = imnoise(Iref, 'salt & pepper', 0.05);
rng(2); R = rand(size(Iref)); N.salt = Iref;   N.salt(R < 0.1)   = 1;
rng(3); R = rand(size(Iref)); N.pepper = Iref; N.pepper(R < 0.1) = 0;
N.params = struct('gaussVar', 0.01, 'spDensity', 0.05, ...
                  'saltProb', 0.1, 'pepperProb', 0.1);
end
